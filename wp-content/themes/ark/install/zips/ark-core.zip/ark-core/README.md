New feature implemented: Images in background - checked(no issues)

- if "Compensate white space under header on mobile (XS) and tablet (SM)" is enabled
  it makes blank area of same height as the header is (on mobiles and tablets)

- if "Compensate white space under header on laptop (MD) and desktop (LG)" is enabled
  it does not count in the heigh of topbar to compute the height of compensation area