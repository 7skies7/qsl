<?php

interface ffIOptionsHolder {
//	public function getOptions();
}